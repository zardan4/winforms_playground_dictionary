﻿using System.Reflection;

public class Translation
{
    public string English;
    public string Ukrainian;

    public Translation(string TranslationEnglish, string TranslationUkrainian)
    {
        English = TranslationEnglish;
        Ukrainian = TranslationUkrainian;
    }
}